module.exports = {
  resetMocks: true,
};
