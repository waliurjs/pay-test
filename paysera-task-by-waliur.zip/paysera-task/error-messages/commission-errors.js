const UNKNOWN_TRANSACTION_TYPE = `Only transaction of type 'cash_in' or 'cash_out' are supported.`;
const UNKNOWN_USER_TYPE = `Only user of type 'natural' or 'juridical' are supported.`;
export default { UNKNOWN_TRANSACTION_TYPE, UNKNOWN_USER_TYPE };
